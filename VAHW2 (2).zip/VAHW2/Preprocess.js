const fs = require('fs');

// Function to handle missing data
function handleMissingData(data) {
  // Example: Remove rows with missing values
  return data.filter(entry => Object.values(entry).every(value => value !== null && value !== undefined));
}

// Function to clean data
function cleanData(data) {
  // Example: Remove duplicate records
  const uniqueData = Array.from(new Set(data.map(entry => JSON.stringify(entry)))).map(entry => JSON.parse(entry));
  return uniqueData;
}

// Function to transform data
function transformData(data) {
  // Example: Aggregate data by year and count the number of events
  const eventCountsByYear = {};
  data.forEach(entry => {
    const year = entry.Year;
    if (eventCountsByYear[year]) {
      eventCountsByYear[year]++;
    } else {
      eventCountsByYear[year] = 1;
    }
  });
  return eventCountsByYear;
}

// Read the dataset file
const filePath = "C:\\Users\\shiva\\OneDrive\\Documents\\VAHW2\\Summer-Olympic-medals-1976-to-2008.csv";

fs.readFile(filePath, 'utf8', (err, data) => {
  if (err) {
    console.error('Error reading the file:', err);
    return;
  }
  
  // Split the data into rows
  const rows = data.split('\n').map(row => row.trim());
  
  // Parse the CSV data into objects
  const headers = rows[0].split(',');
  const dataset = rows.slice(1).map(row => {
    const values = row.split(',');
    const entry = {};
    headers.forEach((header, index) => {
      entry[header] = values[index];
    });
    return entry;
  });
  
  // Preprocess the dataset
  const cleanedData = handleMissingData(dataset);
  const uniqueData = cleanData(cleanedData);
  const transformedData = transformData(uniqueData);
  console.log(transformedData);
});
