#Sorting the data by price in descending order
SELECT * FROM laptop_pricing_dataset ORDER BY Price DESC;

#Filtering laptops with a screen size larger than 15 inches
SELECT * FROM laptop_pricing_dataset WHERE Screen_Size_cm > 15;

#Aggregating the average price of laptops by manufacturer
SELECT Manufacturer, AVG(Price) AS Avg_Price FROM laptop_pricing_dataset GROUP BY Manufacturer;

#Counting the number of laptops in each category
SELECT Category, COUNT(*) AS Laptop_Count FROM laptop_pricing_dataset GROUP BY Category;

#Finding the maximum storage capacity (in GB) among laptops
SELECT MAX(Storage_GB_SSD) AS Max_Storage_GB FROM laptop_pricing_dataset;
